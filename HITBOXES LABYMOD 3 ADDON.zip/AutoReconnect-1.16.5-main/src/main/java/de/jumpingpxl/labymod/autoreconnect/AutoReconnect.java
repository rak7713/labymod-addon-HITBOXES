package de.jumpingpxl.labymod.autoreconnect;

import de.jumpingpxl.labymod.autoreconnect.listener.GuiOpenListener;
import de.jumpingpxl.labymod.autoreconnect.util.Settings;
import net.labymod.api.LabyModAddon;
import net.labymod.api.event.Subscribe;
import net.labymod.api.event.events.client.TickEvent;
import net.labymod.api.event.events.client.renderer.RenderWorldLastEvent;
import net.labymod.ingamegui.Module;
import net.labymod.settings.elements.SettingsElement;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.util.InputMappings;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;
import java.util.List;
import java.util.NoSuchElementException;

public class AutoReconnect extends LabyModAddon {

	public static final int VERSION = 4;

	private Settings settings;
	private ServerData lastServer;
	private double sizeH = 0.3D;
	private boolean isFlag = false;
	@Subscribe
	public void onTick(TickEvent event) {
		if (InputMappings.isKeyDown(Minecraft.getInstance().getMainWindow().getHandle(), GLFW.GLFW_KEY_KP_ADD)) {
			this.sizeH += 0.1D;
		}
		if (InputMappings.isKeyDown(Minecraft.getInstance().getMainWindow().getHandle(), GLFW.GLFW_KEY_KP_SUBTRACT)) {
			this.sizeH -= 0.1D;
		}
		if (InputMappings.isKeyDown(Minecraft.getInstance().getMainWindow().getHandle(), GLFW.GLFW_KEY_INSERT)) {
			this.isFlag = !this.isFlag;
		}
		for (final PlayerEntity entityPlayer : Module.mc.world.getPlayers()) {
			if (entityPlayer != null && entityPlayer != Module.mc.player) {
				entityPlayer.setBoundingBox(new AxisAlignedBB(
						entityPlayer.getPosX() - sizeH,
						entityPlayer.getBoundingBox().minY,
						entityPlayer.getPosZ() - sizeH,
						entityPlayer.getPosX() + sizeH,
						entityPlayer.getBoundingBox().maxY,
						entityPlayer.getPosZ() + sizeH
				));
			}
		}
	}

	@Override
	public void onEnable() {
		settings = new Settings(this);

		getApi().getEventService().registerListener(new GuiOpenListener(this, settings));
		getApi().getEventService().registerListener(this);
	}

	@Override
	public void loadConfig() {
		settings.loadConfig();
	}

	@Override
	protected void fillSettings(List<SettingsElement> settingsElements) {
		settings.fillSettings(settingsElements);
	}

	public ServerData getLastServer() {
		return lastServer;
	}

	public void setLastServer(ServerData lastServer) {
		this.lastServer = lastServer;
	}

	public Field findField(Class<?> clazz, String... fieldNames) {
		for (String fieldName : fieldNames) {
			try {
				Field f = clazz.getDeclaredField(fieldName);
				f.setAccessible(true);
				return f;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		throw new NoSuchElementException();
	}
}
